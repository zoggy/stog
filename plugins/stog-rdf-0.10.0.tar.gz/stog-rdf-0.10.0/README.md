This is a plugin for [Stog](http://zoggy.github.com/stog/).
See [Details](http://zoggy.github.com/stog/plugins/rdf.html).
