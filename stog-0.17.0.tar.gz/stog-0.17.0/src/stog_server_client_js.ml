(*********************************************************************************)
(*                Stog                                                           *)
(*                                                                               *)
(*    Copyright (C) 2012-2015 INRIA All rights reserved.                         *)
(*    Author: Maxence Guesdon, INRIA Saclay                                      *)
(*                                                                               *)
(*    This program is free software; you can redistribute it and/or modify       *)
(*    it under the terms of the GNU General Public License as                    *)
(*    published by the Free Software Foundation, version 3 of the License.       *)
(*                                                                               *)
(*    This program is distributed in the hope that it will be useful,            *)
(*    but WITHOUT ANY WARRANTY; without even the implied warranty of             *)
(*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the               *)
(*    GNU General Public License for more details.                               *)
(*                                                                               *)
(*    You should have received a copy of the GNU General Public                  *)
(*    License along with this program; if not, write to the Free Software        *)
(*    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA                   *)
(*    02111-1307  USA                                                            *)
(*                                                                               *)
(*    As a special exception, you have permission to link this program           *)
(*    with the OCaml compiler and distribute executables, as long as you         *)
(*    follow the requirements of the GNU GPL in regard to all of the             *)
(*    software in the executable aside from the OCaml compiler.                  *)
(*                                                                               *)
(*    Contact: Maxence.Guesdon@inria.fr                                          *)
(*                                                                               *)
(*********************************************************************************)

(** *)

open Stog_server_types

module Xdiff = Xmldiff
module Xdiffjs = Xmldiff_js

let msg_box_id = "stog-server-preview-msgbox";;
let action_box_id = "stog-server-preview-actionbox";;
let cls_button = "button";;
let preview_style_url = "styles/stog-server-style.css";;

let log s = Firebug.console##log (Js.string s);;

let mathjax_active =
  (* need to remember it mathjax was active, since in case of page
     updatefrom a server message, mathjax typeset is not called.
     It is called after the document is loaded, not when it changes. *)
  let mathjax_was_active = ref false in
  fun () ->
    !mathjax_was_active ||
      (
       let doc = Dom_html.document##getElementById(Js.string "MathJax_Message") in
       Js.Opt.case doc (fun _ -> false) (fun _ -> mathjax_was_active := true; true)
      )

let mathjax_typeset () =
  Js.Unsafe.eval_string("MathJax.Hub.Queue([\"Typeset\",MathJax.Hub]);")

let skip_node http_url node =
  match Dom.nodeType node with
    Dom.Element e ->
      (
       match String.lowercase_ascii (Js.to_string (e##tagName)) with
         "div" ->
           (
            let skip =
              Js.Opt.case (e##getAttribute (Js.string "id"))
                (fun _ -> false)
                (fun js ->
                  let s = Js.to_string js in
                  s = msg_box_id ||
                  s = action_box_id ||
                  s = "MathJax_Message")
            in
            skip ||
              Js.Opt.case (e##getAttribute (Js.string "style"))
              (fun _ -> false)
              (fun js ->
                 let s = Js.to_string js in
                 s <> "")
           )
       | "link" ->
           (
            Js.Opt.case (e##getAttribute (Js.string "href"))
              (fun _ -> false)
              (fun js -> Js.to_string js = http_url^"/"^preview_style_url)
           )
       | _ -> false
      )
  | _ -> false


let display_msg xmls =
  let nodes = List.map Xtmpl_js.dom_of_xtmpl xmls in
  Ojsmsg_js.display_message msg_box_id nodes
;;

let display_error xmls =
  let nodes = List.map Xtmpl_js.dom_of_xtmpl xmls in
  Ojsmsg_js.display_error msg_box_id nodes

let add_action_box ws http_url =
  let add () =
    let doc = Dom_html.document in
    let nodes = doc##getElementsByTagName (Js.string "body") in
    Js.Opt.iter (nodes##item(0))
      (fun body_node ->
         let atts = Xdiff.atts_of_list [ ("","id"), action_box_id ] in
         let node = Xdiffjs.dom_of_xml (`E (("","div"), atts, [])) in
         ignore(body_node##insertBefore(node, body_node##firstChild));
         let buttons =
           [ "↺",
             (fun () ->
                let msg = `Stog_msg `Refresh in
                log "click on refresh";
                let json = Stog_server_types.wsdata_of_client_msg msg in
                ws##send (Js.string json);
                display_msg [Xtmpl_rewrite.cdata "Recomputing has been asked, please wait..."]
             ) ;
           ]
         in
         let add_button (label, callback) =
           let b = doc##createElement (Js.string "span") in
           Ojs_js.node_set_class b (cls_button) ;
           let t = doc##createTextNode (Js.string label) in
           Ojs_js.set_onclick b (fun _ -> callback ());
           Dom.appendChild node b ;
           Dom.appendChild b t
         in
         List.iter add_button buttons
      )
  in
  let doc = Dom_html.document##getElementById (Js.string action_box_id) in
  Js.Opt.case doc add (fun _ -> ())

let add_msg_box http_url =
  let add () =
    let doc = Dom_html.document in
    let nodes = doc##getElementsByTagName (Js.string "body") in
    Js.Opt.iter (nodes##item(0))
      (fun body_node ->
         let atts = Xdiff.atts_of_list [ ("","id"), msg_box_id ] in
         let node = Xdiffjs.dom_of_xml (`E (("","div"), atts, [])) in
         ignore(body_node##insertBefore(node, body_node##firstChild));
      );
    let nodes = doc##getElementsByTagName (Js.string "head") in
    Js.Opt.iter (nodes##item(0))
      (fun head_node ->
         let atts = Xdiff.atts_of_list [
             ("","href"), http_url^"/"^preview_style_url ;
             ("","rel"), "stylesheet" ;
             ("","type"), "text/css";
           ]
         in
         let node = Xdiffjs.dom_of_xml (`E (("","link"), atts, [])) in
         ignore(head_node##insertBefore(node, head_node##firstChild));
      );
  in
  let doc = Dom_html.document##getElementById (Js.string msg_box_id) in
  Js.Opt.case doc add (fun _ -> ())
;;

let set_page_content ws http_url xml =
  log "set_page_content";
  let doc = Dom_html.document in

  let children = doc##childNodes in
  log ("got children ("^(string_of_int (children##length)^")"));
  for i=0 to children##length-1 do
      Js.Opt.iter (doc##firstChild) (fun node -> Dom.removeChild doc node) ;
    (*Js.Opt.iter (children##item (i)) (fun node -> Dom.removeChild doc node) (* (children##item (i))*)*)
  done;
  log "building tree";
  let tree = Xtmpl_js.dom_of_xtmpl xml in
  log "appending tree";
  Dom.appendChild doc tree;

  add_msg_box http_url;
  add_action_box ws http_url ;
  log "done";
;;

let stop_updating ws_connection  =
  ws_connection##close()
;;

let update ws http_url page_path (path,op) =
  (*log (Printf.sprintf "receiving update for %s\npage_path=%s" path page_path);*)
  try
    match op with
      _ when path <> page_path -> ()
    | Patch patch ->
        log "patch received";
        Xdiffjs.apply_dom_patch ~skip_node: (skip_node http_url) patch ;
        if mathjax_active () then mathjax_typeset ();
        display_msg [Xtmpl_rewrite.cdata "Page patched !"]
    | Update_all xml ->
        set_page_content ws http_url xml;
        if mathjax_active () then mathjax_typeset ();
        display_msg [Xtmpl_rewrite.cdata "Page updated !"]
  with e ->
    log (Printexc.to_string e)
;;

let display_errors ~errors ~warnings =
  let block cls = function
    [] -> []
  | msgs ->
      [Xtmpl_rewrite.node ("","pre")
        ~atts: (Xtmpl_rewrite.atts_of_list [("","class"), [Xtmpl_rewrite.cdata cls]])
          [ Xtmpl_rewrite.cdata (String.concat "\n" msgs) ]
      ]
  in
  let xmls = (block "error" errors) @ (block "warning" warnings) in
  display_error xmls
;;

let handle_server_message ws http_url page_path = function
  Update (path, op) -> update ws http_url page_path (path, op)
| Errors (errors, warnings) -> display_errors ~errors ~warnings
;;

let ws_onmessage ws http_url page_path _ event =
  try
    log "message received on ws";
    let hex = Js.to_string event##data in
    let marshalled = Stog_server_types.from_hex hex in
    let (mes : Stog_server_types.server_message) = Marshal.from_string marshalled 0 in
    handle_server_message ws http_url page_path mes ;
    Js._false
  with
   e ->
      log (Printexc.to_string e);
      Js._false
;;

let set_up_ws_connection ~path ~ws_url ~http_url =
  try
    log ("connecting with websocket to "^ws_url);
    let ws = jsnew WebSockets.webSocket(Js.string ws_url) in
    ws##onopen <- Dom.handler
      (fun _ ->
         let msg = `Stog_msg (`Get path) in
         let json = Stog_server_types.wsdata_of_client_msg msg in
         ws##send (Js.string json); Js._false
      );
    ws##onclose <- Dom.handler (fun _ -> log "WS now CLOSED"; Js._false);
    (*log "handler set up";
    (
      match ws##readyState with
        | WebSockets.CONNECTING -> log "CONNECTING"
        | WebSockets.OPEN -> log "OPEN"
        | WebSockets.CLOSING -> log "CLOSING"
        | WebSockets.CLOSED -> log "CLOSED"
    );
    *)
    ws##onmessage <- Dom.full_handler (ws_onmessage ws http_url path) ;
    Some ws
  with e ->
    log (Printexc.to_string e);
    None
;;

let stog_server =
  (Js.Unsafe.variable "stog_server" :>
   < wsUrl : Js.js_string Js.t Js.prop ;
     httpUrl : Js.js_string Js.t Js.prop ;
     doc : Js.js_string Js.t Js.prop  ;
   > Js.t )

let ws_url = Js.to_string stog_server##wsUrl
let http_url = Js.to_string stog_server##httpUrl
let path = Js.to_string stog_server##doc

let rec remove_ending_slash s =
  let len = String.length s in
  if len > 0 && String.get s (len-1) = '/' then
    remove_ending_slash (String.sub s 0 (len - 1))
  else
    s

let http_url = remove_ending_slash http_url
let ws_url = remove_ending_slash ws_url
let _ = set_up_ws_connection ~path ~ws_url ~http_url
